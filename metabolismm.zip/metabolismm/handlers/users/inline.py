from aiogram import types
from aiogram.dispatcher.filters import Command, CommandStart


from loader import dp, bot
from utils.db_api import quick_commands


@dp.inline_handler(text="")
async def empty_query(query: types.InlineQuery):
    await query.answer(
        results=[
            types.InlineQueryResultArticle(
                id="unknown",
                title="Начните вводить название продукта!",
                input_message_content=types.InputTextMessageContent(
                    message_text=f"Чтобы узнать калорийность продукта - начните вводить его название",
                    parse_mode="HTML"
                ),
            ),
        ],

        cache_time=5)




@dp.inline_handler()
async def empty_query(query: types.InlineQuery):
    food = await quick_commands.select_food_name(query)
    print(food.id)
    await query.answer(
            results=[
                types.InlineQueryResultArticle(
                                               id="none",
                                               title=f"{food.name}",
                                               input_message_content=types.InputTextMessageContent(
                                                   message_text=(f"<b>Название продукта:</b> {food.name}\n\n"
                                                                 f"<b>Белки:</b> {food.proteins} <b>Грамм</b>\n"
                                                                 f"<b>Жиры:</b> {food.fats} <b>Грамм</b>\n"
                                                                 f"<b>Углеводы:</b> {food.carbohydrates} <b>Грамм</b>\n\n"
                                                                 f"<b>Калорийность:</b> {food.calories} <b>Ккал</b>\n\n"
                                                                 f"<code> показатели на 100 грамм продукта</code>"

                                                                 ),
                                                   parse_mode="HTML",
                                               )
                                               ),
            ],

            cache_time=5)
