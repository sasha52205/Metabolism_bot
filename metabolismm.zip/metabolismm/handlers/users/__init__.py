from .inline import dp
from .admin import dp
from .help import dp
from .start import dp
from .update_db import dp


__all__ = ["dp"]
